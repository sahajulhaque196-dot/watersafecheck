// src/app/page.tsx
import type { Metadata } from 'next'
import Link from 'next/link'
import { getAllStateData } from '@/lib/data'
import { SITE_DESCRIPTION, SITE_NAME } from '@/lib/seo'
import { HomeSearch } from '@/components/sections/HomeSearch'
import { blogArticles } from '@/data/blog-articles'
import { AdTop, AdInContent } from '@/components/ui/AdSense'

export const metadata: Metadata = {
  title: `${SITE_NAME} — Check Tap Water Safety by ZIP Code`,
  description: SITE_DESCRIPTION,
  alternates: { canonical: 'https://www.watersafecheck.com' },
}

const POPULAR_CITIES = [
  { city: 'New York', state: 'NY', zip: '10001' },
  { city: 'Los Angeles', state: 'CA', zip: '90001' },
  { city: 'Chicago', state: 'IL', zip: '60601' },
  { city: 'Houston', state: 'TX', zip: '77001' },
  { city: 'Phoenix', state: 'AZ', zip: '85001' },
  { city: 'Philadelphia', state: 'PA', zip: '19101' },
  { city: 'San Antonio', state: 'TX', zip: '78201' },
  { city: 'San Diego', state: 'CA', zip: '92101' },
  { city: 'Dallas', state: 'TX', zip: '75201' },
  { city: 'Jacksonville', state: 'FL', zip: '32099' },
  { city: 'Austin', state: 'TX', zip: '78701' },
  { city: 'Columbus', state: 'OH', zip: '43201' },
]

const US_STATES_GRID = [
  ['Alabama','al'],['Alaska','ak'],['Arizona','az'],['Arkansas','ar'],
  ['California','ca'],['Colorado','co'],['Connecticut','ct'],['Delaware','de'],
  ['Florida','fl'],['Georgia','ga'],['Hawaii','hi'],['Idaho','id'],
  ['Illinois','il'],['Indiana','in'],['Iowa','ia'],['Kansas','ks'],
  ['Kentucky','ky'],['Louisiana','la'],['Maine','me'],['Maryland','md'],
  ['Massachusetts','ma'],['Michigan','mi'],['Minnesota','mn'],['Mississippi','ms'],
  ['Missouri','mo'],['Montana','mt'],['Nebraska','ne'],['Nevada','nv'],
  ['New Hampshire','nh'],['New Jersey','nj'],['New Mexico','nm'],['New York','ny'],
  ['North Carolina','nc'],['North Dakota','nd'],['Ohio','oh'],['Oklahoma','ok'],
  ['Oregon','or'],['Pennsylvania','pa'],['Rhode Island','ri'],['South Carolina','sc'],
  ['South Dakota','sd'],['Tennessee','tn'],['Texas','tx'],['Utah','ut'],
  ['Vermont','vt'],['Virginia','va'],['Washington','wa'],['West Virginia','wv'],
  ['Wisconsin','wi'],['Wyoming','wy'],
]

export default function HomePage() {
  const allStates = getAllStateData()

  // National stats
  const totalZips = 41344 // pre-computed from master dataset
  const stateList = Object.values(allStates)
  const totalViolations = stateList.reduce((s, st) => s + st.health_violations, 0)
  const highLeadAvg = Math.round(
    stateList.reduce((s, st) => s + st.high_lead_pct, 0) / stateList.length
  )

  return (
    <>
      {/* ── Hero ── */}
      <section className="bg-gradient-to-br from-brand-900 via-brand-800 to-brand-700 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16 sm:py-24 text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 border border-white/20 rounded-full px-4 py-1.5 text-sm font-medium mb-6">
            <span className="w-2 h-2 bg-green-400 rounded-full animate-pulse" />
            Free EPA Data — Updated 2024
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black mb-4 leading-tight">
            Is Your Tap Water<br />
            <span className="text-water-300">Safe to Drink?</span>
          </h1>
          <p className="text-lg sm:text-xl text-blue-100 mb-8 max-w-2xl mx-auto leading-relaxed">
            Search 41,000+ U.S. ZIP codes for lead levels, water quality grades,
            violations, and contaminant data — powered by official EPA records.
          </p>
          <HomeSearch />
          <p className="text-sm text-blue-200 mt-4">
            No sign-up required. 100% free. Data from EPA SDWIS & Consumer Confidence Reports.
          </p>
        </div>
      </section>

      {/* ── National Stats ── */}
      <section className="bg-white border-b border-gray-100">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-6 text-center">
            <div>
              <p className="text-3xl font-black text-brand-700">{totalZips.toLocaleString()}+</p>
              <p className="text-sm text-gray-500 mt-1">ZIP Codes Covered</p>
            </div>
            <div>
              <p className="text-3xl font-black text-brand-700">50</p>
              <p className="text-sm text-gray-500 mt-1">States + DC</p>
            </div>
            <div>
              <p className="text-3xl font-black text-orange-600">{(totalViolations / 1000).toFixed(0)}K+</p>
              <p className="text-sm text-gray-500 mt-1">Health Violations Found</p>
            </div>
            <div>
              <p className="text-3xl font-black text-red-600">{highLeadAvg}%</p>
              <p className="text-sm text-gray-500 mt-1">High Lead Risk ZIPs</p>
            </div>
          </div>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <AdTop />

        {/* ── How It Works ── */}
        <section className="mb-14">
          <h2 className="text-3xl font-black text-center text-gray-900 mb-2">How WaterSafeCheck Works</h2>
          <p className="text-center text-gray-500 mb-10 max-w-2xl mx-auto">
            We aggregate official EPA data into clear, actionable water quality reports for every ZIP code in America.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {[
              {
                step: '1',
                icon: '🔍',
                title: 'Enter Your ZIP Code',
                desc: 'Type in any U.S. ZIP code to instantly access water quality data for your exact service area.',
              },
              {
                step: '2',
                icon: '📊',
                title: 'View Your Water Report',
                desc: 'See your water safety grade (A–F), lead levels in ppb, health violations, contaminants detected, and more — all from official EPA sources.',
              },
              {
                step: '3',
                icon: '🛡',
                title: 'Take Action if Needed',
                desc: 'Get tailored recommendations based on your specific water data, including filter suggestions, utility contacts, and health resources.',
              },
            ].map(item => (
              <div key={item.step} className="card text-center">
                <div className="w-12 h-12 rounded-full bg-brand-100 text-brand-700 font-black text-lg flex items-center justify-center mx-auto mb-3">
                  {item.step}
                </div>
                <div className="text-3xl mb-3">{item.icon}</div>
                <h3 className="font-bold text-gray-900 mb-2">{item.title}</h3>
                <p className="text-sm text-gray-500 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ── Why Water Quality Matters ── */}
        <section className="mb-14 bg-blue-50 rounded-2xl p-8">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">Why Check Your Tap Water?</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-sm text-gray-700">
              <div>
                <p className="font-semibold text-gray-900 mb-1">🚰 Lead Contamination</p>
                <p>The EPA estimates that 10–20% of human lead exposure comes from drinking water. Lead has no safe exposure level for children and can cause irreversible neurological damage.</p>
              </div>
              <div>
                <p className="font-semibold text-gray-900 mb-1">🧪 PFAS "Forever Chemicals"</p>
                <p>PFAS chemicals have been detected in water supplies serving millions of Americans. The EPA issued its first federal PFAS MCLs in 2024, setting limits at 4 parts per trillion.</p>
              </div>
              <div>
                <p className="font-semibold text-gray-900 mb-1">🌿 Disinfection Byproducts</p>
                <p>When chlorine used to treat water reacts with organic matter, it forms trihalomethanes (TTHMs) and haloacetic acids (HAA5s) — compounds linked to increased cancer risk with long-term exposure.</p>
              </div>
              <div>
                <p className="font-semibold text-gray-900 mb-1">🏚 Aging Infrastructure</p>
                <p>Over 6 million lead service lines still deliver water to American homes. The EPA's Lead and Copper Rule requires utilities to identify and replace these pipes, but it will take years.</p>
              </div>
            </div>
            <div className="mt-6">
              <Link href="/water-quality-guide" className="btn-primary inline-flex">
                Read the Complete Water Safety Guide →
              </Link>
            </div>
          </div>
        </section>

        <AdInContent />

        {/* ── Popular Cities ── */}
        <section className="mb-14">
          <h2 className="text-2xl font-bold text-gray-900 mb-1">Popular City Water Reports</h2>
          <p className="text-sm text-gray-500 mb-6">Check water quality for major U.S. cities</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
            {POPULAR_CITIES.map(({ city, state, zip }) => (
              <Link
                key={zip}
                href={`/city/${city.toLowerCase().replace(/\s+/g, '-')}-${state.toLowerCase()}`}
                className="card-hover group block"
              >
                <p className="font-semibold text-sm text-gray-800 group-hover:text-brand-700 transition-colors">
                  {city}, {state}
                </p>
                <p className="text-xs text-gray-400 mt-0.5">View water quality →</p>
              </Link>
            ))}
          </div>
        </section>

        {/* ── Browse by State ── */}
        <section className="mb-14">
          <h2 className="text-2xl font-bold text-gray-900 mb-1">Browse Water Quality by State</h2>
          <p className="text-sm text-gray-500 mb-6">View all ZIP codes and city reports for any U.S. state</p>
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
            {US_STATES_GRID.map(([name, code]) => {
              const st = allStates[code.toUpperCase()]
              return (
                <Link
                  key={code}
                  href={`/state/${code}`}
                  className="flex items-center justify-between px-3 py-2.5 rounded-lg border border-gray-100 hover:border-brand-200 hover:bg-brand-50 transition-all group"
                >
                  <span className="text-sm text-gray-700 group-hover:text-brand-700 font-medium">{name}</span>
                  {st && (
                    <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${
                      st.avg_score && st.avg_score >= 75 ? 'text-green-700 bg-green-50' :
                      st.avg_score && st.avg_score >= 60 ? 'text-blue-700 bg-blue-50' :
                      'text-orange-700 bg-orange-50'
                    }`}>
                      {st.avg_score ? `${st.avg_score}` : '—'}
                    </span>
                  )}
                </Link>
              )
            })}
          </div>
        </section>

        {/* ── Blog / Latest Articles ── */}
        <section className="mb-14">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-2xl font-bold text-gray-900 mb-1">Water Safety Articles</h2>
              <p className="text-sm text-gray-500">Plain-English guides on tap water safety, filters, and EPA data</p>
            </div>
            <Link href="/blog" className="text-sm text-brand-700 hover:underline font-medium hidden sm:block">
              View all articles →
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {blogArticles.slice(0, 3).map(article => (
              <Link key={article.slug} href={`/blog/${article.slug}`} className="card-hover group block">
                <p className="text-xs text-brand-600 font-semibold mb-1.5">{article.category}</p>
                <h3 className="text-sm font-bold text-gray-800 group-hover:text-brand-700 transition-colors leading-snug mb-2 line-clamp-2">
                  {article.title}
                </h3>
                <p className="text-xs text-gray-500 leading-relaxed line-clamp-2 mb-3">
                  {article.intro.slice(0, 120)}...
                </p>
                <div className="flex items-center justify-between">
                  <span className="text-xs text-gray-400">{article.readTime}</span>
                  <span className="text-xs text-brand-600 font-semibold">Read →</span>
                </div>
              </Link>
            ))}
          </div>
          <div className="mt-4 text-center sm:hidden">
            <Link href="/blog" className="text-sm text-brand-700 hover:underline font-medium">
              View all articles →
            </Link>
          </div>
        </section>

        {/* ── Data Source Trust ── */}}
        <section className="bg-gray-50 rounded-2xl p-8 mb-6">
          <h2 className="text-xl font-bold text-gray-900 mb-4 text-center">Trusted Data Sources</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center text-sm">
            <div className="flex flex-col items-center gap-2">
              <span className="text-3xl">🏛</span>
              <p className="font-semibold text-gray-800">EPA SDWIS</p>
              <p className="text-gray-500">Safe Drinking Water Information System — the EPA's official compliance database for 150,000+ public water systems</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <span className="text-3xl">📋</span>
              <p className="font-semibold text-gray-800">Consumer Confidence Reports</p>
              <p className="text-gray-500">Annual water quality reports that utilities are legally required to publish, containing actual contaminant measurements</p>
            </div>
            <div className="flex flex-col items-center gap-2">
              <span className="text-3xl">🔬</span>
              <p className="font-semibold text-gray-800">EPA UCMR5 Monitoring</p>
              <p className="text-gray-500">The EPA's 5th Unregulated Contaminant Monitoring Rule — the most comprehensive PFAS screening of U.S. water systems ever conducted</p>
            </div>
          </div>
          <p className="text-xs text-gray-400 text-center mt-6">
            All data is sourced from public U.S. government databases. WaterSafeCheck does not conduct independent water testing.
            Data reflects monitoring records and may not reflect current real-time conditions.
          </p>
        </section>
      </div>
    </>
  )
}
