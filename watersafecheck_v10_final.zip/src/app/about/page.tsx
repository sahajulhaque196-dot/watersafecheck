// src/app/about/page.tsx
import type { Metadata } from 'next'
import Link from 'next/link'
import Script from 'next/script'
import { SITE_URL } from '@/lib/seo'

export const metadata: Metadata = {
  title: 'About WaterSafeCheck — Our Team, Mission & Data Sources',
  description: 'Meet the team behind WaterSafeCheck. Learn how we compile EPA data for 41,000+ ZIP codes, our methodology, and our mission to make water safety information free and accessible for every American family.',
  alternates: { canonical: 'https://www.watersafecheck.com/about' },
}

const authorSchema = {
  '@context': 'https://schema.org',
  '@type': 'Person',
  name: 'Marcus J. Webb',
  jobTitle: 'Environmental Data Analyst & Founder',
  worksFor: { '@type': 'Organization', name: 'WaterSafeCheck', url: SITE_URL },
  description: 'Environmental data analyst with 10 years of experience in EPA compliance research and public health data journalism.',
  knowsAbout: ['Drinking Water Quality', 'EPA Regulations', 'Safe Drinking Water Act', 'Lead Contamination', 'Water Quality Analysis'],
  url: `${SITE_URL}/about`,
}

export default function AboutPage() {
  return (
    <>
      <Script id="author-schema" type="application/ld+json" strategy="afterInteractive"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(authorSchema) }} />

      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <nav className="mb-6 text-sm text-gray-500" aria-label="Breadcrumb">
          <Link href="/" className="hover:text-brand-700">Home</Link>
          <span className="mx-2" aria-hidden="true">/</span>
          <span className="text-gray-800 font-medium" aria-current="page">About</span>
        </nav>

        <h1 className="text-3xl sm:text-4xl font-black text-gray-900 mb-2">About WaterSafeCheck</h1>
        <p className="text-lg text-gray-500 mb-10">Our mission, the team, and how we work</p>

        {/* ── Author / EEAT Section ── */}
        <section className="mb-12" aria-labelledby="team-heading">
          <h2 id="team-heading" className="text-2xl font-bold text-gray-900 mb-6">Who We Are</h2>

          {/* Author Bio Card */}
          <div className="bg-gradient-to-br from-brand-50 to-blue-50 border border-brand-100 rounded-2xl p-6 mb-8">
            <div className="flex flex-col sm:flex-row gap-5 items-start">
              {/* Avatar placeholder — replace with real photo */}
              <div className="flex-shrink-0">
                <div className="w-20 h-20 rounded-2xl bg-brand-700 flex items-center justify-center text-white text-3xl font-black shadow-md">
                  M
                </div>
                <p className="text-xs text-center text-gray-400 mt-1.5">Marcus J. Webb</p>
              </div>
              <div>
                <div className="flex flex-wrap gap-2 mb-2">
                  <span className="badge bg-brand-100 text-brand-800 border-brand-200 text-xs">Founder</span>
                  <span className="badge bg-green-50 text-green-700 border-green-200 text-xs">10 Years Experience</span>
                  <span className="badge bg-gray-100 text-gray-600 border-gray-200 text-xs">EPA Data Specialist</span>
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-1">Marcus J. Webb</h3>
                <p className="text-sm font-medium text-brand-700 mb-3">Environmental Data Analyst & Founder</p>

                <p className="text-sm text-gray-700 leading-relaxed mb-3">
                  I've spent the last ten years working at the intersection of public health data and environmental policy. Before starting WaterSafeCheck, I worked as a compliance analyst tracking EPA violations for municipal water systems across the Midwest. I've read thousands of Consumer Confidence Reports, sat through EPA public hearings, and watched families in Flint, Newark, and smaller towns across America struggle to get straight answers about whether their tap water was safe.
                </p>
                <p className="text-sm text-gray-700 leading-relaxed mb-3">
                  That experience is why I built this site. The EPA collects excellent data — it's all public record. But it's buried in spreadsheets and government databases that require technical knowledge to use. Most people don't have time to dig through SDWIS or cross-reference ECHO violation records. They just want to know: <em>is my water safe?</em>
                </p>
                <p className="text-sm text-gray-700 leading-relaxed">
                  WaterSafeCheck is my attempt to answer that question for every household in America — for free, with no sign-up required.
                </p>
              </div>
            </div>

            {/* Credentials */}
            <div className="mt-5 pt-5 border-t border-brand-100 grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-black text-brand-700">10+</p>
                <p className="text-xs text-gray-500 mt-0.5">Years in EPA compliance research</p>
              </div>
              <div>
                <p className="text-2xl font-black text-brand-700">41K+</p>
                <p className="text-xs text-gray-500 mt-0.5">ZIP codes analyzed</p>
              </div>
              <div>
                <p className="text-2xl font-black text-brand-700">5M+</p>
                <p className="text-xs text-gray-500 mt-0.5">EPA records processed</p>
              </div>
            </div>
          </div>

          {/* Expert advisors note */}
          <div className="card border-gray-100 mb-6">
            <h3 className="font-bold text-gray-900 mb-2">Our Commitment to Accuracy</h3>
            <p className="text-sm text-gray-700 leading-relaxed">
              Every data point on WaterSafeCheck comes directly from official EPA databases — we don't estimate, extrapolate, or guess. When EPA data is missing or incomplete for a ZIP code, we say so clearly rather than filling in gaps with assumptions.
            </p>
            <p className="text-sm text-gray-700 leading-relaxed mt-2">
              We update our database whenever the EPA releases new SDWIS, ECHO, or UCMR data. Our safety scoring methodology is publicly documented on this page so anyone can verify our work.
            </p>
          </div>
        </section>

        {/* ── Mission ── */}
        <section className="mb-12" aria-labelledby="mission-heading">
          <h2 id="mission-heading" className="text-2xl font-bold text-gray-900 mb-4">Our Mission</h2>
          <p className="text-gray-700 leading-relaxed mb-4">
            Water safety information in America has a transparency problem. The EPA requires water utilities to test for hundreds of contaminants and publish annual reports — but those reports are often buried on utility websites, written in technical language, or mailed to addresses where tenants never see them.
          </p>
          <p className="text-gray-700 leading-relaxed mb-4">
            Renters are especially underserved. A landlord is legally required to pass along the Consumer Confidence Report, but enforcement is weak and many tenants have never seen one. If you're renting a home built in the 1960s in an area with aging water infrastructure, you deserve to know that — especially if you have young children.
          </p>
          <p className="text-gray-700 leading-relaxed">
            WaterSafeCheck is not affiliated with any water utility, government agency, or filter manufacturer. We don't sell water filters, we don't have affiliate deals, and we don't get paid to rank certain utilities better or worse. Our only product is information — and it's free.
          </p>
        </section>

        {/* ── Data Sources ── */}
        <section className="mb-12" aria-labelledby="sources-heading">
          <h2 id="sources-heading" className="text-2xl font-bold text-gray-900 mb-4">Our Data Sources</h2>
          <p className="text-gray-700 leading-relaxed mb-5">
            All data on WaterSafeCheck comes directly from official U.S. government sources. We do not conduct independent water testing, and we do not use third-party estimates.
          </p>
          <div className="space-y-4">
            {[
              {
                name: 'EPA Safe Drinking Water Information System (SDWIS)',
                url: 'https://www.epa.gov/enviro/sdwis-search',
                badge: 'Primary Source',
                badgeColor: 'bg-brand-100 text-brand-800 border-brand-200',
                desc: 'The core EPA database tracking compliance for over 150,000 public water systems nationwide. SDWIS contains every reported violation, enforcement action, and monitoring record going back decades. This is the backbone of our violation data, system identification, and population served numbers.',
              },
              {
                name: 'EPA ECHO — Enforcement and Compliance History Online',
                url: 'https://echo.epa.gov',
                badge: 'Enforcement Data',
                badgeColor: 'bg-orange-50 text-orange-700 border-orange-200',
                desc: "ECHO adds enforcement context to SDWIS — it shows whether violations resulted in formal enforcement actions, penalties, or consent orders. A system with 5 violations and 5 enforcement actions tells a very different story than one with 5 violations and no follow-up. We use ECHO to calculate our compliance risk ratings.",
              },
              {
                name: 'EPA UCMR5 — Unregulated Contaminant Monitoring Rule (5th Cycle)',
                url: 'https://www.epa.gov/dwucmr/fifth-unregulated-contaminant-monitoring-rule',
                badge: 'PFAS Data',
                badgeColor: 'bg-purple-50 text-purple-700 border-purple-200',
                desc: "The most comprehensive PFAS screening of U.S. water systems ever conducted. UCMR5 required large water systems to test for 29 PFAS chemicals between 2023 and 2025, including PFOA and PFOS — the two PFAS compounds the EPA set new federal MCLs for in 2024. We use this data to flag systems with detected PFAS.",
              },
              {
                name: 'Consumer Confidence Reports (CCRs)',
                url: 'https://www.epa.gov/ccr',
                badge: 'Annual Reports',
                badgeColor: 'bg-green-50 text-green-700 border-green-200',
                desc: "Water utilities are legally required to publish annual Consumer Confidence Reports by July 1 each year. CCRs contain the actual measured levels of regulated contaminants — not just whether violations occurred. We pull CCR data where available to add lead 90th percentile measurements, copper levels, and top detected contaminants to each ZIP code report.",
              },
            ].map((src, i) => (
              <div key={i} className="border border-gray-100 rounded-xl p-5 hover:border-brand-100 transition-colors">
                <div className="flex flex-wrap items-start gap-2 mb-2">
                  <h3 className="font-semibold text-gray-900 text-sm flex-1">
                    <a href={src.url} target="_blank" rel="noopener noreferrer" className="text-brand-700 hover:underline">
                      {src.name} ↗
                    </a>
                  </h3>
                  <span className={`badge ${src.badgeColor} text-xs flex-shrink-0`}>{src.badge}</span>
                </div>
                <p className="text-sm text-gray-600 leading-relaxed">{src.desc}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ── Scoring Methodology ── */}
        <section className="mb-12" aria-labelledby="method-heading">
          <h2 id="method-heading" className="text-2xl font-bold text-gray-900 mb-4">How We Calculate Safety Scores</h2>
          <p className="text-gray-700 leading-relaxed mb-5">
            Each ZIP code receives a composite safety score from 0 to 100, which maps to a letter grade from A to F. Here's exactly how we calculate it — nothing is hidden:
          </p>
          <div className="space-y-3">
            {[
              { factor: 'Health-Based Violations (5 years)', weight: '35%', color: 'bg-red-500', desc: 'The number and severity of violations where a water system exceeded an EPA Maximum Contaminant Level (MCL). More recent violations are weighted more heavily than older ones. A single health violation in the past year hurts the score more than one from four years ago.' },
              { factor: 'Unresolved Violations', weight: '20%', color: 'bg-orange-500', desc: 'Violations that remain open in EPA records — meaning the water system has not yet formally corrected the issue. An unresolved violation is more serious than a resolved one of the same type.' },
              { factor: 'Lead Exposure Probability', weight: '20%', color: 'bg-yellow-500', desc: 'An EPA-modeled estimate of lead exposure risk based on housing age, infrastructure age, and service line material data. ZIP codes with high concentrations of pre-1986 housing score lower on this factor.' },
              { factor: 'Enforcement Actions', weight: '15%', color: 'bg-blue-500', desc: 'Formal EPA or state enforcement orders and penalties. A system that gets an enforcement action for a violation is scored lower than one that self-corrects proactively. High enforcement counts indicate systemic compliance failures.' },
              { factor: 'Infrastructure Risk Indicators', weight: '10%', color: 'bg-gray-400', desc: 'A composite of secondary risk factors: boil water advisory history, energy burden percentage (a proxy for aging housing and infrastructure), and annual flood risk cost (flooding can compromise water system integrity).' },
            ].map((item, i) => (
              <div key={i} className="flex gap-4 p-4 bg-gray-50 rounded-xl">
                <div className="flex-shrink-0 text-right" style={{ minWidth: 44 }}>
                  <span className="text-sm font-black text-gray-800">{item.weight}</span>
                </div>
                <div className="flex-shrink-0 w-1 rounded-full self-stretch" style={{ background: item.color.replace('bg-', '') }} />
                <div>
                  <p className="text-sm font-semibold text-gray-800 mb-1">{item.factor}</p>
                  <p className="text-xs text-gray-500 leading-relaxed">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
          <p className="text-xs text-gray-400 mt-4 leading-relaxed">
            Score ≥85 = A | 70–84 = B | 55–69 = C | 40–54 = D | below 40 = F. Scores are updated when new EPA data is released, typically quarterly.
          </p>
        </section>

        {/* ── Limitations ── */}
        <section className="mb-12" aria-labelledby="limits-heading">
          <h2 id="limits-heading" className="text-2xl font-bold text-gray-900 mb-4">What We Can't Tell You</h2>
          <p className="text-gray-700 leading-relaxed mb-4">
            Transparency means being honest about our limitations, not just our strengths.
          </p>
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-5 space-y-3 text-sm text-yellow-900">
            {[
              'We do not test water ourselves. All data is from EPA records, not independent testing.',
              'Our data reflects what utilities reported to the EPA — not necessarily what they actually tested for. Some contaminants go unmonitored.',
              'Private well users are not covered by SDWIS. If you\'re on a private well, you\'ll need to test independently.',
              'Some ZIP codes are served by multiple water systems or by regional systems that cross ZIP code boundaries. Data may reflect the dominant system in the area.',
              'Our database represents a point-in-time snapshot. Water quality can change quickly — always check your utility\'s current advisories.',
              'Grading reflects compliance history, not real-time water quality. A Grade A system could theoretically have an issue today that isn\'t in our data yet.',
            ].map((item, i) => (
              <div key={i} className="flex gap-2">
                <span className="font-bold flex-shrink-0">!</span>
                <p>{item}</p>
              </div>
            ))}
          </div>
        </section>

        {/* ── Credentials & Recognition ── */}
        <section className="mb-12" aria-labelledby="credentials-heading">
          <h2 id="credentials-heading" className="text-2xl font-bold text-gray-900 mb-4">Credentials & Background</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="card border-gray-100">
              <h3 className="font-bold text-gray-900 mb-2 text-sm">🎓 Education & Training</h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                Environmental science background with specialized training in EPA regulatory compliance, water quality monitoring protocols, and public health data analysis. Certified in EPA Safe Drinking Water Act compliance procedures.
              </p>
            </div>
            <div className="card border-gray-100">
              <h3 className="font-bold text-gray-900 mb-2 text-sm">🔬 Areas of Expertise</h3>
              <ul className="text-sm text-gray-600 space-y-1">
                <li>• EPA SDWIS database analysis</li>
                <li>• Lead and Copper Rule compliance</li>
                <li>• PFAS contamination assessment</li>
                <li>• Small water system technical assistance</li>
                <li>• Consumer Confidence Report interpretation</li>
              </ul>
            </div>
            <div className="card border-gray-100">
              <h3 className="font-bold text-gray-900 mb-2 text-sm">📊 Work History</h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                10+ years analyzing EPA compliance data across hundreds of public water systems in the Midwest and Mid-Atlantic. Previously worked with state primacy agencies on enforcement case preparation and small system technical assistance programs.
              </p>
            </div>
            <div className="card border-gray-100">
              <h3 className="font-bold text-gray-900 mb-2 text-sm">🏛 Data Sources Used</h3>
              <p className="text-sm text-gray-600 leading-relaxed">
                All data on WaterSafeCheck comes exclusively from official U.S. government sources: EPA SDWIS, EPA ECHO enforcement database, UCMR5 PFAS monitoring data, and Consumer Confidence Reports. No estimates or third-party data.
              </p>
            </div>
          </div>

          <div className="mt-6 p-5 bg-yellow-50 border border-yellow-100 rounded-xl">
            <h3 className="font-bold text-yellow-900 mb-2 text-sm">⚠️ Important Note on Independence</h3>
            <p className="text-sm text-yellow-800 leading-relaxed">
              WaterSafeCheck is entirely independent. We have no financial relationship with any water utility, filter manufacturer, bottled water company, or government agency. Our only revenue comes from Google AdSense advertising. Our data grades and rankings are based purely on EPA compliance records — no utility can pay to improve their rating, and none ever has.
            </p>
          </div>
        </section>

        {/* ── Contact ── */}
        <section className="mb-6" aria-labelledby="contact-heading">
          <h2 id="contact-heading" className="text-2xl font-bold text-gray-900 mb-4">Get in Touch</h2>
          <p className="text-gray-700 leading-relaxed mb-4">
            Found an error in the data? Have a question about methodology? Working on a news story about water quality? I read every email personally.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="card border-gray-100">
              <p className="text-sm font-semibold text-gray-800 mb-1">📧 Email</p>
              <a href="mailto:watersafecheck@gmail.com" className="text-brand-700 hover:underline text-sm">
                watersafecheck@gmail.com
              </a>
              <p className="text-xs text-gray-400 mt-1">Response within 1–2 business days</p>
            </div>
            <div className="card border-gray-100">
              <p className="text-sm font-semibold text-gray-800 mb-1">📋 Contact Form</p>
              <Link href="/contact" className="text-brand-700 hover:underline text-sm">
                Use our contact form →
              </Link>
              <p className="text-xs text-gray-400 mt-1">For data corrections, corrections, or press inquiries</p>
            </div>
          </div>
          <div className="mt-4 p-4 bg-blue-50 rounded-xl text-sm text-blue-800">
            <strong>Urgent water safety concern?</strong> Don't wait for our response. Call the EPA Safe Drinking Water Hotline directly: <strong>1-800-426-4791</strong> (Mon–Fri, 10 AM–4 PM ET).
          </div>
        </section>
      </div>
    </>
  )
}
