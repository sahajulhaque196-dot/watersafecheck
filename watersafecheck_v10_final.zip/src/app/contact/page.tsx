'use client'
// src/app/contact/page.tsx
import type { Metadata } from 'next'
import Link from 'next/link'

export const metadata: Metadata = {
  title: 'Contact WaterSafeCheck — Data Questions, Corrections & Inquiries',
  description: 'Contact WaterSafeCheck for data questions, corrections, media inquiries, or general help understanding your tap water quality report. We respond within 1–2 business days.',
  alternates: { canonical: 'https://www.watersafecheck.com/contact' },
}

export default function ContactPage() {
  return (
    <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      <nav className="mb-6 text-sm text-gray-500" aria-label="Breadcrumb">
        <Link href="/" className="hover:text-brand-700">Home</Link>
        <span className="mx-2" aria-hidden="true">/</span>
        <span className="text-gray-800 font-medium" aria-current="page">Contact</span>
      </nav>

      <h1 className="text-3xl sm:text-4xl font-black text-gray-900 mb-2">Contact Us</h1>
      <p className="text-gray-500 mb-8 text-lg">
        Questions, corrections, or just want to understand your water report better? We're here.
      </p>

      {/* Direct contact options */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-8">
        <div className="card border-brand-100 bg-brand-50">
          <div className="text-2xl mb-2">📧</div>
          <h2 className="font-bold text-gray-900 mb-1">Email Us Directly</h2>
          <a
            href="mailto:watersafecheck@gmail.com"
            className="text-brand-700 font-semibold hover:underline break-all"
          >
            watersafecheck@gmail.com
          </a>
          <p className="text-xs text-gray-500 mt-2">
            We read every email personally. Typical response: 1–2 business days.
          </p>
        </div>
        <div className="card border-gray-100">
          <div className="text-2xl mb-2">📞</div>
          <h2 className="font-bold text-gray-900 mb-1">Urgent Water Safety?</h2>
          <p className="text-brand-700 font-bold text-lg">1-800-426-4791</p>
          <p className="text-xs text-gray-500 mt-1">
            EPA Safe Drinking Water Hotline<br />
            Mon–Fri, 10 AM–4 PM Eastern
          </p>
        </div>
      </div>

      {/* Contact form pointing to Gmail */}
      <div className="card mb-8">
        <h2 className="font-bold text-gray-900 mb-1">Send Us a Message</h2>
        <p className="text-sm text-gray-500 mb-5">
          This form sends directly to <strong>watersafecheck@gmail.com</strong>. You can also email us there directly.
        </p>

        {/*
          DEPLOYMENT: Replace the action URL with your Formspree endpoint.
          1. Go to formspree.io → Sign up free
          2. New Form → get endpoint like: https://formspree.io/f/xyzabc12
          3. Replace YOUR_FORM_ID below with your actual form ID
          Until then, the mailto fallback works directly.
        */}
        <form
          action="https://formspree.io/f/YOUR_FORM_ID"
          method="POST"
          onSubmit={(e) => {
            // Fallback: if Formspree not configured, open mailto
            const action = (e.currentTarget as HTMLFormElement).action;
            if (action.includes('YOUR_FORM_ID')) {
              e.preventDefault();
              const data = new FormData(e.currentTarget as HTMLFormElement);
              const subject = encodeURIComponent(`WaterSafeCheck: ${data.get('subject') || 'Contact'}`);
              const body = encodeURIComponent(`Name: ${data.get('name')}\nEmail: ${data.get('email')}\nZIP: ${data.get('zip')}\n\n${data.get('message')}`);
              window.location.href = `mailto:watersafecheck@gmail.com?subject=${subject}&body=${body}`;
            }
          }}
          className="space-y-5"
        >
          <input type="hidden" name="_replyto" value="watersafecheck@gmail.com" />
          <input type="hidden" name="_subject" value="WaterSafeCheck Contact Form" />
          <input type="text" name="_gotcha" className="hidden" aria-hidden="true" />

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-1">
                Your Name <span className="text-red-500" aria-hidden="true">*</span>
              </label>
              <input
                id="name"
                name="name"
                type="text"
                required
                autoComplete="name"
                placeholder="Jane Smith"
                className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100 transition-all"
              />
            </div>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">
                Your Email <span className="text-red-500" aria-hidden="true">*</span>
              </label>
              <input
                id="email"
                name="email"
                type="email"
                required
                autoComplete="email"
                placeholder="jane@example.com"
                className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100 transition-all"
              />
            </div>
          </div>

          <div>
            <label htmlFor="subject" className="block text-sm font-medium text-gray-700 mb-1">
              What's this about? <span className="text-red-500" aria-hidden="true">*</span>
            </label>
            <select
              id="subject"
              name="subject"
              required
              className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100 bg-white"
            >
              <option value="">Select a topic...</option>
              <option value="data-question">Question about my water quality data</option>
              <option value="data-correction">I think there's an error in the data</option>
              <option value="zip-missing">My ZIP code has no data</option>
              <option value="understand-report">Help understanding my water report</option>
              <option value="media">Media / press inquiry</option>
              <option value="other">Something else</option>
            </select>
          </div>

          <div>
            <label htmlFor="zip" className="block text-sm font-medium text-gray-700 mb-1">
              Your ZIP Code <span className="text-xs text-gray-400 font-normal">(optional — helps us look up your data)</span>
            </label>
            <input
              id="zip"
              name="zip"
              type="text"
              inputMode="numeric"
              maxLength={5}
              placeholder="e.g. 90210"
              className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100"
            />
          </div>

          <div>
            <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-1">
              Your Message <span className="text-red-500" aria-hidden="true">*</span>
            </label>
            <textarea
              id="message"
              name="message"
              rows={5}
              required
              placeholder="Tell us what you're wondering about or what you found..."
              className="w-full px-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:border-brand-500 focus:ring-2 focus:ring-brand-100 resize-none"
            />
          </div>

          <button
            type="submit"
            className="btn-primary w-full py-3 text-base"
          >
            Send Message
          </button>

          <p className="text-xs text-gray-400 text-center">
            Or email us directly at{' '}
            <a href="mailto:watersafecheck@gmail.com" className="text-brand-600 hover:underline">
              watersafecheck@gmail.com
            </a>
          </p>
        </form>
      </div>

      {/* FAQ for contact page */}
      <div className="card border-gray-100 mb-6">
        <h2 className="font-bold text-gray-900 mb-4">Common Questions</h2>
        <div className="space-y-4 text-sm">
          <div>
            <p className="font-semibold text-gray-800 mb-1">My ZIP code shows no data. Why?</p>
            <p className="text-gray-600">
              A small number of ZIP codes may fall between water system service boundaries, or be served by very small systems that report under a parent utility ID. Contact us with your ZIP and we'll investigate. You can also try searching your city name or a neighboring ZIP code.
            </p>
          </div>
          <div className="border-t border-gray-50 pt-4">
            <p className="font-semibold text-gray-800 mb-1">I think the data for my area is wrong. What should I do?</p>
            <p className="text-gray-600">
              Send us the ZIP code and what you believe is incorrect. We'll compare against the original EPA source data and update if there's an error. You can also verify directly at{' '}
              <a href="https://echo.epa.gov" target="_blank" rel="noopener noreferrer" className="text-brand-700 underline">echo.epa.gov</a>.
            </p>
          </div>
          <div className="border-t border-gray-50 pt-4">
            <p className="font-semibold text-gray-800 mb-1">Can I use WaterSafeCheck data in my news article or research?</p>
            <p className="text-gray-600">
              Yes — the underlying EPA data is public domain. Please attribute "WaterSafeCheck, based on EPA SDWIS and ECHO data." For research partnerships or data exports, email us directly.
            </p>
          </div>
          <div className="border-t border-gray-50 pt-4">
            <p className="font-semibold text-gray-800 mb-1">How quickly do you respond?</p>
            <p className="text-gray-600">
              We typically respond within 1–2 business days. For urgent water safety concerns (contamination advisory, active boil water notice), please contact the EPA hotline at 1-800-426-4791 rather than waiting for our reply.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
