// src/lib/content.ts
// Data-driven content engine — all text is conditional on real EPA data
// This is NOT AI-generated filler — every sentence reflects actual data values

import type { ZipData, StateData } from './types'
import { getContaminantList, formatLeadPpb } from './data'

// ─── ZIP Page Content ─────────────────────────────────────────────────────

export function getZipIntro(d: ZipData): string {
  const city = d.city || 'this area'
  const state = d.state || ''
  const grade = d.grade
  const score = d.score
  const sysName = d.system_name || 'the local water utility'

  if (grade === 'A') {
    return `Tap water in ZIP code ${d.zip} (${city}, ${state}) is among the safest in the country. Served by ${sysName}, this area earned a water safety grade of <strong>A</strong> with a composite score of ${score}/100 — indicating full regulatory compliance and low contaminant risk across EPA monitoring periods.`
  }
  if (grade === 'B') {
    return `Tap water in ZIP code ${d.zip} (${city}, ${state}) meets all federal safety standards and earns a solid <strong>B</strong> grade (score: ${score}/100). Served by ${sysName}, the water system has maintained general compliance with EPA Safe Drinking Water Act regulations, with only minor issues on record.`
  }
  if (grade === 'C') {
    return `Tap water in ZIP code ${d.zip} (${city}, ${state}) receives a <strong>C</strong> grade (score: ${score}/100) based on EPA monitoring data. While the water from ${sysName} is treated and regulated, this area has a moderate violation history that residents should be aware of.`
  }
  if (grade === 'D') {
    return `Tap water in ZIP code ${d.zip} (${city}, ${state}) has received a <strong>D</strong> grade (score: ${score}/100) — below average for the nation. ${sysName} has recorded notable violations with EPA Safe Drinking Water Act regulations. Residents may want to consider additional filtration and review their annual Consumer Confidence Report.`
  }
  if (grade === 'F') {
    return `Tap water in ZIP code ${d.zip} (${city}, ${state}) has received a failing <strong>F</strong> grade (score: ${score}/100) based on EPA compliance data. ${sysName} has a significant history of water quality violations. <strong>Residents are strongly encouraged to use a certified water filter and contact their local water authority for current advisories.</strong>`
  }
  return `Water quality data for ZIP code ${d.zip} (${city}, ${state}) is based on EPA Safe Drinking Water Act monitoring records from ${sysName}.`
}

export function getLeadSection(d: ZipData): { headline: string; body: string; severity: 'safe' | 'warning' | 'danger' | 'unknown' } {
  if (d.lead_mg_l === null && d.ccr_lead_ppb === null) {
    return {
      headline: 'Lead Data Not Available',
      body: `Lead testing data was not found in EPA records for ZIP code ${d.zip}. This may occur with very small systems or systems that report under a parent utility. Contact ${d.system_name || 'your water utility'} directly to request lead testing results or a copy of their Consumer Confidence Report.`,
      severity: 'unknown',
    }
  }

  const ppb = d.lead_mg_l !== null ? d.lead_mg_l * 1000 : null
  const ccrPpb = d.ccr_lead_ppb

  if (ppb !== null) {
    if (ppb === 0) {
      return {
        headline: 'Lead Not Detected',
        body: `Lead was not detected in water samples from ZIP code ${d.zip}. The 90th percentile lead level — the EPA standard measurement — was 0 ppb, well below the EPA action level of 15 ppb and the health goal of 0 ppb. Even with undetectable tap water lead, older homes built before 1986 may have lead service lines or plumbing fixtures that can leach lead into water as it sits.`,
        severity: 'safe',
      }
    }
    if (ppb <= 5) {
      return {
        headline: `Lead Level: ${ppb.toFixed(1)} ppb — Very Low`,
        body: `The 90th percentile lead level in ${d.zip} is <strong>${ppb.toFixed(1)} ppb</strong>, well below the EPA action level of 15 ppb. While this is a reassuring result, the EPA's public health goal for lead is actually zero — no amount of lead is considered completely safe, particularly for children under 6 and pregnant women. Running your tap for 30 seconds before use and using a certified NSF/ANSI 53 filter adds an extra layer of protection.`,
        severity: 'safe',
      }
    }
    if (ppb <= 10) {
      return {
        headline: `Lead Level: ${ppb.toFixed(1)} ppb — Below Action Level`,
        body: `The 90th percentile lead level in ${d.zip} is <strong>${ppb.toFixed(1)} ppb</strong>, below the EPA action level of 15 ppb but above what many health experts consider ideal. The CDC and EPA both affirm there is no safe level of lead exposure for children. Families with young children or pregnant women should consider a certified NSF/ANSI 53 water filter, and request lead testing of their home's tap water.`,
        severity: 'warning',
      }
    }
    if (ppb <= 15) {
      return {
        headline: `Lead Level: ${ppb.toFixed(1)} ppb — Approaching Action Level`,
        body: `The 90th percentile lead level in ${d.zip} is <strong>${ppb.toFixed(1)} ppb</strong>, approaching the EPA action level of 15 ppb. When a water system's 90th percentile exceeds this threshold, the utility is required to take corrective action including public notification and infrastructure upgrades. Residents — especially those with children or in homes built before 1986 — should use a certified lead-reducing filter (NSF/ANSI 53 or 58) for drinking and cooking water.`,
        severity: 'warning',
      }
    }
    return {
      headline: `Lead Level: ${ppb.toFixed(1)} ppb — EXCEEDS EPA Action Level`,
      body: `<strong>The 90th percentile lead level in ${d.zip} is ${ppb.toFixed(1)} ppb, which EXCEEDS the EPA action level of 15 ppb.</strong> This is a serious concern. The water utility is legally required to notify residents, identify the source of contamination, and take corrective action. Do not give this water to infants, children, or pregnant women without first passing it through a certified NSF/ANSI 53 water filter. Contact ${d.system_name || 'your water utility'} immediately for current guidance, or call the EPA Safe Drinking Water Hotline at 1-800-426-4791.`,
      severity: 'danger',
    }
  }

  // Fallback to CCR ppb
  if (ccrPpb !== null) {
    return {
      headline: `Lead Level (CCR Report): ${ccrPpb.toFixed(1)} ppb`,
      body: `According to the Consumer Confidence Report for ${d.zip}, the 90th percentile lead level is <strong>${ccrPpb.toFixed(1)} ppb</strong>. ${ccrPpb > 15 ? 'This exceeds the EPA action level of 15 ppb — residents should use a certified water filter.' : ccrPpb > 5 ? 'This is below the EPA action level of 15 ppb. Families with young children should still consider using a certified lead filter.' : 'This is at a low level, well below the EPA action level of 15 ppb.'}`,
      severity: ccrPpb > 15 ? 'danger' : ccrPpb > 5 ? 'warning' : 'safe',
    }
  }

  return {
    headline: 'Lead Data Unavailable',
    body: 'Lead testing data could not be retrieved for this ZIP code from EPA records.',
    severity: 'unknown',
  }
}

export function getViolationNarrative(d: ZipData): string {
  const h = d.health_violations
  const t = d.total_violations
  const u = d.unresolved_violations
  const system = d.system_name || 'This water system'

  let text = ''

  if (h === 0 && t === 0) {
    text = `${system} has recorded <strong>zero violations</strong> in the EPA compliance database over the past 5 years — a strong indicator of consistent regulatory compliance and careful monitoring.`
  } else if (h === 0 && t > 0) {
    text = `${system} has recorded ${t} violation${t > 1 ? 's' : ''}, but <strong>none are health-based</strong>. Administrative or reporting violations don't directly indicate unsafe water, but they do signal gaps in documentation or monitoring procedures.`
  } else if (h === 1) {
    text = `${system} has recorded <strong>1 health-based violation</strong> in the past 5 years. A single health violation means the water exceeded an EPA maximum contaminant level (MCL) at some point. Most water systems resolve these quickly, but residents should review the Consumer Confidence Report for details.`
  } else if (h <= 5) {
    text = `${system} has recorded <strong>${h} health-based violations</strong> in the past 5 years. Multiple health violations suggest recurring compliance challenges. Residents should request a copy of the annual Consumer Confidence Report to understand what contaminants were involved and what corrective actions were taken.`
  } else {
    text = `${system} has recorded <strong>${h} health-based violations</strong> in the past 5 years — significantly above the national average. This volume of violations indicates serious and recurring compliance issues. Independent water testing and in-home filtration are strongly recommended.`
  }

  if (u > 0) {
    text += ` <strong>${u} violation${u > 1 ? 's are' : ' is'} currently unresolved</strong> — meaning the issue has not yet been formally corrected in EPA records. This is a serious concern that residents should follow up on with their water utility.`
  }

  if (d.boil_water_advisories > 0) {
    text += ` Additionally, this area has had <strong>${d.boil_water_advisories} boil water advisory${d.boil_water_advisories > 1 ? 's' : ''}</strong> — temporary orders issued when microbial contamination risk is elevated.`
  }

  return text
}

export function getContaminantNarrative(d: ZipData): string {
  const contaminants = getContaminantList(d.contaminants)
  if (contaminants.length === 0) {
    return `No health-based contaminant violations are on record for ZIP code ${d.zip}. This means EPA monitoring has not found levels of regulated contaminants exceeding the Maximum Contaminant Levels (MCLs) set under the Safe Drinking Water Act — a positive indicator of water quality compliance.`
  }

  const cList = contaminants.slice(0, 5).join(', ')
  const more = contaminants.length > 5 ? ` and ${contaminants.length - 5} more` : ''

  return `EPA records identify <strong>${contaminants.length} contaminant${contaminants.length > 1 ? 's' : ''}</strong> associated with health-based violations in ZIP code ${d.zip}: <strong>${cList}${more}</strong>. These contaminants exceeded the Maximum Contaminant Levels (MCLs) established by the EPA under the Safe Drinking Water Act at some point in the 5-year monitoring period. The presence of these violations does not necessarily mean water is currently unsafe — water systems are often required to increase monitoring and treatment when violations occur. Review the annual Consumer Confidence Report for the most current status.`
}

export function getEnforcementNarrative(d: ZipData): string {
  if (d.enforcement_actions === 0) {
    return `No enforcement actions have been taken against ${d.system_name || 'this water system'} in the EPA records. This is the expected outcome for utilities maintaining consistent compliance.`
  }
  if (d.enforcement_actions <= 2) {
    return `EPA or state regulators have issued <strong>${d.enforcement_actions} enforcement action${d.enforcement_actions > 1 ? 's' : ''}</strong> against ${d.system_name || 'this water system'}. Enforcement actions are formal compliance orders or penalties issued when a utility fails to address violations within required timeframes.`
  }
  return `<strong>${d.enforcement_actions} enforcement actions</strong> have been issued against ${d.system_name || 'this water system'} — a high number that reflects sustained compliance struggles. Enforcement actions escalate from administrative orders to financial penalties when utilities repeatedly fail to meet safe drinking water standards.`
}

export function getLeadRiskNarrative(d: ZipData): string {
  const risk = d.lead_risk
  const prob = d.lead_prob

  if (!risk) return ''

  const probText = prob !== null ? ` EPA models estimate a <strong>${prob}% probability</strong> of lead exposure risk in this ZIP code based on housing age, infrastructure age, and water system data.` : ''

  if (risk === 'Low') {
    return `Lead exposure risk in ${d.zip} is rated <strong>Low</strong>.${probText} This rating reflects newer infrastructure, lower housing age, and/or low detected lead levels. Standard precautions — flushing taps before use, using filtered water for infants — are still recommended.`
  }
  if (risk === 'Moderate') {
    return `Lead exposure risk in ${d.zip} is rated <strong>Moderate</strong>.${probText} This may reflect a mix of older and newer housing stock and infrastructure. Families with young children should test their home's water and consider a certified NSF/ANSI 53 water filter.`
  }
  if (risk === 'High') {
    return `Lead exposure risk in ${d.zip} is rated <strong>High</strong>.${probText} This typically reflects older housing stock built before 1986 (when lead pipes were banned), aging distribution infrastructure, or detected lead levels in water samples. Families should prioritize getting their tap water tested independently and installing a certified lead-reducing filter.`
  }
  if (risk === 'Very High') {
    return `Lead exposure risk in ${d.zip} is rated <strong>Very High</strong>.${probText} This is among the highest risk categories nationally, often associated with heavily aging infrastructure and pre-1986 construction. Do not give unfiltered tap water to children under 6 or pregnant women. Consider getting your home's plumbing tested for lead solder and fixtures.`
  }
  return ''
}

export function getComplianceNarrative(d: ZipData): string {
  const risk = d.compliance_risk
  if (!risk) return ''

  if (risk === 'Low') return `Regulatory compliance risk for ${d.system_name || 'this water system'} is rated <strong>Low</strong> — indicating a consistent track record of meeting EPA reporting and treatment requirements.`
  if (risk === 'Moderate') return `Regulatory compliance risk is rated <strong>Moderate</strong>. ${d.system_name || 'This water system'} has had occasional lapses in compliance but generally meets Safe Drinking Water Act requirements.`
  if (risk === 'High') return `Regulatory compliance risk is rated <strong>High</strong>. ${d.system_name || 'This water system'} has a pattern of compliance issues that goes beyond isolated incidents. Residents should stay informed via their utility's Consumer Confidence Report.`
  if (risk === 'Critical') return `Regulatory compliance risk is rated <strong>Critical</strong> — the highest risk category. ${d.system_name || 'This water system'} has an extensive history of unresolved violations and enforcement actions. Independent water testing is highly recommended.`
  return ''
}

export function getWaterQualityFAQs(d: ZipData): { q: string; a: string }[] {
  const city = d.city || 'this area'
  const state = d.state || ''
  const zip = d.zip
  const ppb = d.lead_mg_l !== null ? (d.lead_mg_l * 1000).toFixed(1) : null

  return [
    {
      q: `Is tap water safe to drink in ZIP code ${zip}?`,
      a: d.grade === 'A' || d.grade === 'B'
        ? `Yes — tap water in ${zip} (${city}, ${state}) currently meets all federal EPA standards with a water safety grade of ${d.grade}. No health-based violations are on record in the past 5 years. You can drink your tap water with confidence, though running the tap for 30 seconds in the morning is always a good practice.`
        : d.grade === 'C'
        ? `Tap water in ${zip} (${city}, ${state}) is treated and regulated, but has a grade of ${d.grade} due to past violations. For most healthy adults, treated tap water is generally safe. Families with infants, young children, or immunocompromised individuals may want to use a certified water filter as a precaution.`
        : `Tap water in ${zip} has a below-average water quality grade of ${d.grade}. While it is treated, there have been notable compliance issues. We strongly recommend using a certified NSF/ANSI 53 water filter for drinking and cooking, especially for vulnerable populations.`
    },
    {
      q: `What is the lead level in ${zip} tap water?`,
      a: ppb !== null
        ? `The 90th percentile lead level in ${zip} is ${ppb} ppb (parts per billion). The EPA action level is 15 ppb. ${parseFloat(ppb) > 15 ? 'This exceeds the EPA action level — use a certified lead-reducing water filter.' : parseFloat(ppb) > 5 ? 'This is below the action level, but some health experts recommend a lead filter for families with young children.' : 'This is a low level, well below the EPA action level of 15 ppb.'}`
        : `Lead level data from EPA monitoring is not available for ${zip}. Contact ${d.system_name || 'your local water utility'} directly for the most recent lead testing results.`
    },
    {
      q: `Who provides tap water to ${zip}?`,
      a: d.system_name
        ? `Tap water in ZIP code ${zip} is provided by <strong>${d.system_name}</strong> (EPA ID: ${d.pwsid}). This system serves approximately ${d.population?.toLocaleString() || 'an unknown number of'} residents. You can contact them directly for Consumer Confidence Reports, current advisories, and billing information.`
        : `Water utility information is not available in the EPA database for ${zip}. Check with your local municipality or use the EPA's ECHO database for details.`
    },
    {
      q: `What is the water source for ${zip}?`,
      a: d.water_source
        ? `ZIP code ${zip} is served by <strong>${d.water_source.toLowerCase()}</strong>. ${d.water_source === 'Surface Water' ? 'Surface water systems draw from rivers, lakes, or reservoirs and must meet strict EPA treatment requirements including filtration and disinfection.' : 'Groundwater systems draw from underground aquifers. While naturally filtered, groundwater can still contain naturally occurring contaminants such as arsenic, radium, or nitrates at elevated levels in some regions.'}`
        : `Water source data is not available for ${zip} in the EPA database.`
    },
    {
      q: `Does ${zip} have any active water quality violations?`,
      a: d.unresolved_violations > 0
        ? `Yes — there are currently <strong>${d.unresolved_violations} unresolved violation${d.unresolved_violations > 1 ? 's' : ''}</strong> on record for this water system. Unresolved violations indicate issues that have not yet been formally corrected in EPA tracking systems. Contact ${d.system_name || 'your water utility'} for the latest update.`
        : d.health_violations > 0
        ? `There are ${d.health_violations} health-based violation${d.health_violations > 1 ? 's' : ''} in the past 5-year record, but no currently unresolved violations according to EPA data. This means past issues have been addressed.`
        : `No active violations are on record for ZIP code ${zip}. EPA data shows this water system is currently in compliance with Safe Drinking Water Act standards.`
    },
    {
      q: `How do I get a copy of my water quality report for ${zip}?`,
      a: `Your water utility — ${d.system_name || 'the local water provider'} — is required by law to send you an annual Consumer Confidence Report (CCR) by July 1 each year. You can also request it directly from the utility or find it online by searching "${d.system_name || city + ' water'} Consumer Confidence Report." The EPA's ECHO database also has historical compliance data.`
    },
    {
      q: `What water filter should I use in ${zip}?`,
      a: `The right filter depends on what contaminants are present. For lead, look for a filter certified to NSF/ANSI Standard 53. For chlorine byproducts (like THMs), NSF/ANSI 42 filters work well. For a broad range of contaminants including PFAS, look for NSF/ANSI 58 (reverse osmosis) systems. For ZIP code ${zip}, ${d.contaminant_count > 0 ? `with detected contaminants including ${getContaminantList(d.contaminants).slice(0, 2).join(' and ')}, a multi-stage filter or reverse osmosis system is recommended.` : `with a clean compliance record, a standard carbon block filter meeting NSF/ANSI 42 is a good choice for taste and as a precaution.`}`
    },
    {
      q: `Is ${zip} tap water safe for babies and infants?`,
      a: `Infants are especially vulnerable to lead, nitrates, and microbial contaminants in drinking water. ${d.lead_mg_l !== null && d.lead_mg_l * 1000 > 5 ? `Given the detected lead level of ${(d.lead_mg_l * 1000).toFixed(1)} ppb in ${zip}, we recommend using a certified NSF/ANSI 53 water filter or certified bottled water for preparing infant formula.` : `Current EPA data for ${zip} shows ${d.lead_mg_l === null ? 'no available lead data — we recommend using a certified NSF/ANSI 53 lead filter as a precaution for infant formula.' : `a lead level of ${(d.lead_mg_l * 1000).toFixed(1)} ppb — below the action level, but as an extra precaution, run your tap for 30 seconds before use and consider a certified lead filter for infant formula.`}`} Always consult your pediatrician for guidance specific to your child's health.`
    },
  ]
}

// ─── State Page Content ───────────────────────────────────────────────────

export function getStateIntro(d: StateData): string {
  const score = d.avg_score
  const gradeA = d.grade_dist['A'] || 0
  const gradeF = d.grade_dist['F'] || 0
  const total = d.zip_count

  const pctA = Math.round((gradeA / total) * 100)
  const pctF = Math.round((gradeF / total) * 100)

  if (score !== null && score >= 75) {
    return `Tap water quality in <strong>${d.name}</strong> is above the national average, with an average safety score of <strong>${score}/100</strong> across ${total.toLocaleString()} monitored ZIP codes. ${pctA}% of ZIP codes in ${d.name} have earned an "A" grade — reflecting strong regulatory compliance and low contaminant levels across most of the state.`
  }
  if (score !== null && score >= 60) {
    return `Tap water quality in <strong>${d.name}</strong> is near the national average, with an average safety score of <strong>${score}/100</strong> across ${total.toLocaleString()} monitored ZIP codes. While most areas maintain adequate water quality, ${d.name} has recorded ${d.total_violations.toLocaleString()} total violations — including ${d.health_violations.toLocaleString()} health-based violations — over the past 5 years.`
  }
  return `Tap water quality in <strong>${d.name}</strong> is below the national average, with an average safety score of <strong>${score ?? 'N/A'}/100</strong> across ${total.toLocaleString()} monitored ZIP codes. The state has recorded ${d.health_violations.toLocaleString()} health-based violations in the past 5 years. Residents in areas with lower grades should review their Consumer Confidence Report and consider certified water filtration.`
}

export function getStateFAQs(d: StateData): { q: string; a: string }[] {
  return [
    {
      q: `Is tap water safe in ${d.name}?`,
      a: `Tap water safety varies significantly by location in ${d.name}. Statewide, ${d.grade_dist['A'] || 0} ZIP codes earn an "A" grade and ${d.grade_dist['F'] || 0} earn an "F." Search your specific ZIP code above for a detailed safety report for your address.`
    },
    {
      q: `Which cities in ${d.name} have the worst water quality?`,
      a: `Based on EPA violation data, the lowest-scoring water systems in ${d.name} include areas with high lead risk (${d.high_lead_pct}% of ZIP codes are rated High or Very High for lead exposure probability) and ${d.health_violations.toLocaleString()} total health-based violations statewide. Check individual ZIP codes for specific rankings.`
    },
    {
      q: `Who regulates drinking water in ${d.name}?`,
      a: `Drinking water in ${d.name} is primarily regulated by the state's environmental or health agency under a primacy agreement with the U.S. EPA. The EPA's Safe Drinking Water Act sets federal standards (Maximum Contaminant Levels), while states monitor and enforce compliance. Water utilities are required to publish annual Consumer Confidence Reports.`
    },
    {
      q: `How do I find my water quality report in ${d.name}?`,
      a: `Enter your ZIP code in the search box above for a detailed report. You can also contact your local water utility for the annual Consumer Confidence Report (CCR), which is required to be distributed by July 1 each year. The EPA's ECHO database provides additional compliance and enforcement data.`
    },
  ]
}
